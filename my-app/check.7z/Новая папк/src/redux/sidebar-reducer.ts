import {ActionsType, SidebarType} from "./store";

let initialState = {}

export const sidebarReducer = (state=initialState, action: ActionsType) => {
    return state;
}


